# android-jedi

## Curso de Android de JEDI, Enero de 2019


En este repositorio podréis encontrar todo el material que utilizaremos durante el curso, además de bibliografía útil.

El índice de la asignatura está en los documentos en Markdown numerados de este repositorio.



Links útiles
* [Android Studio](https://developer.android.com/studio/)
* [Android developers](https://developer.android.com/)
* [Developer guide](https://developer.android.com/guide/)


