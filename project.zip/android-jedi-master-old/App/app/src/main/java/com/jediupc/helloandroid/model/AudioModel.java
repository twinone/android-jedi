package com.jediupc.helloandroid.model;

import java.io.Serializable;

public class AudioModel implements Serializable {
    public String path;
    public int duration; // in ms
}
