package com.jediupc.helloandroid.navigation;

import android.support.v4.app.Fragment;

public class NavSettingsFragment extends Fragment  {
}
