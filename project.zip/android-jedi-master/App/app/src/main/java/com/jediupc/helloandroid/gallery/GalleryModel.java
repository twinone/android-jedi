package com.jediupc.helloandroid.gallery;

import java.io.Serializable;

public class GalleryModel implements Serializable {
    public String previewURL;
    public String largeImageURL;
}
