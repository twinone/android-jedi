# Layouts, Animations.

En esta sección explicaremos todo lo relevante al diseño, colocación y manipulación de los elementos de la UI.

Aprovecharemos principalmente [la documentación existente de Layouts de Android](https://developer.android.com/guide/topics/ui/declaring-layout).

